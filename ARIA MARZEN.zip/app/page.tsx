import { AutoSliderBanner } from "@/components/auto-slider-banner"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      {/* Full-screen Auto-sliding Banner */}
      <AutoSliderBanner />

      {/* Linktree Section */}
      <section id="linktree-section" className="w-full py-12 md:py-24 bg-dark-900">
        <div className="container mx-auto px-4 max-w-md">
          <h2 className="mb-8 text-3xl font-bold text-center text-gray-100">Links</h2>
          <div className="flex flex-col space-y-4">
            <a
              href="https://www.youtube.com/@AriaMarzen-db9mc"
              className="py-3 px-4 bg-white text-dark-900 rounded-lg text-center font-semibold hover:bg-gray-200 transition-colors"
            >
              Youtube
            </a>
            <a
              href="https://soundcloud.com/socials-741712396?utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing"
              className="py-3 px-4 bg-white text-dark-900 rounded-lg text-center font-semibold hover:bg-gray-200 transition-colors"
            >
              Soundcloud
            </a>
            <a
              href="https://www.instagram.com/ariamarzen/#"
              className="py-3 px-4 bg-white text-dark-900 rounded-lg text-center font-semibold hover:bg-gray-200 transition-colors"
            >
              Instagram
            </a>
            <a
              href="mailto:socials@ariamarzen.com"
              className="py-3 px-4 bg-white text-dark-900 rounded-lg text-center font-semibold hover:bg-gray-200 transition-colors"
            >
              Contact
            </a>
          </div>
        </div>
      </section>
    </main>
  )
}

