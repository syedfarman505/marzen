import Image from "next/image"

export function Logo() {
  return (
    <div className="relative w-[1200px] h-[400px]">
      <Image
        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/PNG-06-0KAiyqX04R2hACczPnBYA1MVQ9Rvig.png"
        alt="Logo"
        fill
        className="object-contain translate-y-8"
        priority
      />
    </div>
  )
}

