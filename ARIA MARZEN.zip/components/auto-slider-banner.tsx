"use client"

import { useEffect, useRef } from "react"
import { Logo } from "./logo"

const videoSrc = "https://va.media.tumblr.com/tumblr_srq84tr6xq1aefqs8.mp4"

export function AutoSliderBanner() {
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.play().catch((error) => {
        console.error("Autoplay was prevented:", error)
      })
    }
  }, [])

  return (
    <div className="relative w-full h-screen overflow-hidden">
      <video
        ref={videoRef}
        src={videoSrc}
        className="absolute top-0 left-0 w-full h-full object-cover"
        loop
        muted
        playsInline
      />
      <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
        <Logo />
      </div>
    </div>
  )
}

